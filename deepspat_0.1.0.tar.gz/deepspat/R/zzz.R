# Environment determining status of the TensorFlow Installation.
# This allows a custom error message to be displayed.
tf_status <- new.env()

# Load TensorFlow and add the contents
.onLoad <- function(libname, pkgname) {

  tf <<- reticulate::import("tensorflow", delay_load = TRUE)

  # Set default tf_status that everything is installed correctly.
  assign("TF", TRUE, envir = tf_status)
  # Check TensorFlow is installed. Update tf_status accordingly.
  checkTF()
  # If checkTF was not successful, return to avoid printing multiple messages
  if (!get("TF", envir = tf_status)) {
    return()
  }
  # Check TensorFlow Probability is installed, and load in. Update tf_status accordingly.
}


# Check tensorflow installed by doing a dummy operation that will throw an error
checkTF = function() {
  tryCatch(temp <- tf$constant(4),
           error = function (e) tfMissing())
}



# Build message if TensorFlow missing. Update tf_status
tfMissing <- function() {
  message("\nNo TensorFlow python installation found.")
  message("This can be installed using the installTF() function.\n")
  assign("TF", FALSE, envir = tf_status)
}
